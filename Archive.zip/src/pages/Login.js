import NormalLayout from "../components/Layout/NormalLayout"

const Login = () => {
    return (
        <NormalLayout>

        </NormalLayout>
    )
}

export default Login