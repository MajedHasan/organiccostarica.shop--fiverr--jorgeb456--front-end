import React from 'react'
import NormalLayout from '../components/Layout/NormalLayout'

const Cart = () => {
    return (
        <NormalLayout>

        </NormalLayout>
    )
}

export default Cart