import React from 'react'

const AdminBoxes = () => {
    return (
        <div>AdminBoxes</div>
    )
}

export default AdminBoxes