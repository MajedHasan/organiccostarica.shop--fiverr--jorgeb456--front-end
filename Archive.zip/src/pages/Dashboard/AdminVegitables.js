import React from 'react'

const AdminVegitables = () => {
    return (
        <div>AdminVegitables</div>
    )
}

export default AdminVegitables