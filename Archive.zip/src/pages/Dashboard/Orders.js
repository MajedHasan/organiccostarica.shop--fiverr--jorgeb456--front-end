import React from 'react'

const Orders = () => {
    return (
        <div>Orders</div>
    )
}

export default Orders