import React from 'react'

const CheckOut = () => {
    return (
        <div>CheckOut</div>
    )
}

export default CheckOut