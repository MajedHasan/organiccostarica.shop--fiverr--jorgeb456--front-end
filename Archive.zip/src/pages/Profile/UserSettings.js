import React from 'react'

const UserSettings = () => {
    return (
        <div>UserSettings</div>
    )
}

export default UserSettings