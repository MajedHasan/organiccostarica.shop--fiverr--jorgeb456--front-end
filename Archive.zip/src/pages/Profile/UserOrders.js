import React from 'react'

const UserOrders = () => {
    return (
        <div>UserOrders</div>
    )
}

export default UserOrders