import React from 'react'
import NormalLayout from '../components/Layout/NormalLayout'

const Signup = () => {
    return (
        <NormalLayout>

        </NormalLayout>
    )
}

export default Signup