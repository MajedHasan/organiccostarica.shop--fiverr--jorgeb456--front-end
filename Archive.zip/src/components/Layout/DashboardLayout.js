import React from 'react'

const DashboardLayout = () => {
    return (
        <div>DashboardLayout</div>
    )
}

export default DashboardLayout