import React from 'react'

const UserLayout = () => {
    return (
        <div>UserLayout</div>
    )
}

export default UserLayout